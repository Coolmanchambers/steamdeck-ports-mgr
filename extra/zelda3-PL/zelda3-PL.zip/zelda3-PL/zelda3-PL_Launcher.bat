@echo off
setlocal EnableExtensions
chcp 65001 >nul
title zelda3-PL Launcher & Color 0A
mode con cols=90 lines=35 >nul 2>&1

cd /d "%~dp0"
set "ROOT=%~dp0"
set "EXE=%ROOT%zelda3.exe"
set "DAT=%ROOT%zelda3_assets.dat"
set RESTOOL="%ROOT%python\python.exe" "%ROOT%python\restool.py"

:: Folders the launcher / game expect next to it (ROMs, translations, MSU audio,
:: Link sprites). Created empty on first run so the user just drops files in.
set "ROMS=%ROOT%roms"
for %%D in (roms languages msu sprites-gfx) do if not exist "%ROOT%%%D\" mkdir "%ROOT%%%D"

if not exist "%ROOT%python\python.exe" (
    echo.
    echo ERROR: bundled python missing at  %ROOT%python\python.exe
    echo.
    pause
    exit 1
)

:MENU
call :HEADER "zelda3-PL Launcher"
if exist "%EXE%" (echo   exe      : ok) else (echo   exe      : MISSING - zelda3.exe must sit next to this launcher)
if exist "%DAT%" (echo   assets   : ok) else (echo   assets   : missing - option 2)
for /f "delims=" %%L in ('type "%ROOT%zelda3.ini" ^| findstr /b /i "Language"') do echo   ini      : %%L
echo   languages:
for /d %%D in ("%ROOT%languages\*") do echo       %%~nxD
echo.
echo   [1] Play
echo   [2] Generate assets   (rebuild zelda3_assets.dat from the US ROM, no languages)
echo   [3] Extract a language from a ROM
echo   [4] Inject languages into zelda3_assets.dat
echo   [5] Auto-detect ROMs  (SHA-1 scan of roms\ , extract every known one)
echo   [6] Test save          (slot 3 = 20 hearts, all items, 9999 rupees, end-game)
echo   [7] Convert Link sprites  (input\ .png ^<-^> .zspr  -^>  output\)
echo   [Q] Quit
echo.
choice /c 1234567Q /n /m "Choice: "
if errorlevel 8 exit 0
if errorlevel 7 goto SPRITE
if errorlevel 6 goto TESTSAVE
if errorlevel 5 goto AUTO
if errorlevel 4 goto INJECT
if errorlevel 3 goto EXTRACT
if errorlevel 2 goto BUILD
goto PLAY

:PLAY
if not exist "%EXE%" (
    echo.
    echo ERROR: zelda3.exe not found next to this launcher.
    echo.
    pause
    goto MENU
)
cls
echo.
echo Launching Zelda3...
echo.
:: Processus detache -- cette fenetre peut se fermer des que le jeu demarre.
start "" "%EXE%"
exit 0

:BUILD
call :HEADER "GENERATE ASSETS"
echo Rebuilding zelda3_assets.dat from the US base ROM, no extra languages.
echo A US "*.sfc" must be in roms\ or next to this launcher.
echo.
%RESTOOL% --extract-from-rom
if errorlevel 1 (
    echo.
    echo FAILED - no US base ROM found, or extraction error.
    echo.
    pause
    goto MENU
)
echo.
echo zelda3_assets.dat regenerated - US text only.
echo.
pause
goto MENU

:EXTRACT
call :HEADER "EXTRACT A LANGUAGE"
echo ROMs in  %ROMS%\  :
for %%F in ("%ROMS%\*.sfc" "%ROMS%\*.smc") do if exist "%%~fF" echo       %%~nxF
echo.
echo   Tip: for Japanese / any known ROM just use option [5] - it matches by
echo        checksum, no need to type the filename.
echo.
set "RF="
set /p "RF=  ROM file name: "
if not defined RF goto MENU
set "RF=%RF:"=%"
if not exist "%ROMS%\%RF%" goto EXTRACT_NOROM
set "NM="
echo.
echo   A known ROM keeps its own code + format (matched by checksum). Any other
echo   name is a US-format folder you can put in zelda3.ini.
set /p "NM=  Language name: "
if not defined NM goto MENU
echo.
%RESTOOL% --extract-dialogue -r "%ROMS%\%RF%" --name "%NM%"
if errorlevel 1 goto EXTRACT_FAIL
echo.
echo   -^> languages\%NM%\    ( option 4 to inject )
echo.
pause
goto MENU

:EXTRACT_NOROM
echo.
echo   not found:  %ROMS%\%RF%
echo.
pause
goto MENU

:EXTRACT_FAIL
echo.
echo   EXTRACTION FAILED.
echo.
pause
goto MENU

:INJECT
call :HEADER "INJECT LANGUAGES"
set "LANGS="
for /d %%D in ("%ROOT%languages\*") do if /i not "%%~nxD"=="us" call set "LANGS=%%LANGS%%,%%~nxD"
if not defined LANGS (
    echo Nothing to inject in languages\ - run option 3 or 5 first.
    echo.
    pause
    goto MENU
)
set "LANGS=%LANGS:~1%"
echo Baking: us,%LANGS%
echo.
%RESTOOL% --extract-from-rom --languages=%LANGS%
if errorlevel 1 (
    echo.
    echo BUILD FAILED.
    echo.
    pause
    goto MENU
)
echo.
echo Done. Set  Language = ^<name^>  in zelda3.ini to use one.
echo.
pause
goto MENU

:TESTSAVE
call :HEADER "TEST SAVE"
echo Writing an all-unlocked file to SAVE SLOT 3 in  saves\sram.dat
echo 20 hearts, full magic + half upgrade, every item, gold sword, 9999 rupees,
echo all pendants + crystals, end-game progress. Other slots are untouched.
echo.
"%ROOT%python\python.exe" "%ROOT%python\make_save.py"
echo.
pause
goto MENU

:SPRITE
call :HEADER "CONVERT LINK SPRITES"
if not exist "%ROOT%input\"  mkdir "%ROOT%input"
if not exist "%ROOT%output\" mkdir "%ROOT%output"
echo Every file in  input\  is converted into  output\  :
echo     input\NAME.png   -^>  output\NAME.zspr
echo     input\NAME.zspr  -^>  output\NAME.png
echo Sheet format: indexed 128x448 PNG, 16 colours, index 0 = transparent.
echo.
"%ROOT%python\python.exe" "%ROOT%python\link_sprite.py"
echo.
echo   -^> output\    ( copy a .zspr next to zelda3.exe, then in zelda3.ini:
echo                    LinkGraphics = NAME.zspr )
echo.
pause
goto MENU

:AUTO
call :HEADER "AUTO-DETECT ROMS"
echo Scanning for ROMs, matching SHA-1, extracting each known one into
echo languages\^<code^>\ ...
echo.
%RESTOOL% --auto
if errorlevel 1 (
    echo.
    echo AUTO-DETECT FAILED.
    echo.
    pause
    goto MENU
)
echo.
echo   -^> languages\    ( use option 4 to inject )
echo.
pause
goto MENU

:HEADER
cls
echo.
echo ============================================================
echo   %~1
echo ============================================================
echo.
exit /b 0
