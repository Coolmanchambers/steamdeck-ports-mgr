# Japanese (ja) support for the asset pipeline.
#
# Unlike de/fr/... (US-family ROMs where only the Latin text bank + VWF font
# differ), the JP ROM stores its dialogue in a 2-byte encoding, and its font
# compressed with a bespoke bit-transpose scheme. Neither fits
# text_compression.py or sprite_sheets.decode_font, so everything JP lives here
# and the pipeline just calls into it for lang == 'ja'.
#   - dialogue: decoded straight from the ROM (decode_dialogue)
#   - font: sliced from jp_font_sheet.png, the ripped decompressed font
#     (extract_font); the ROM's own compression is not reproduced here
#
# Dialogue: raw bytes at SNES $1C8000..$1CF356. 0x00-0xF5 = 1-byte char,
#   0xFD kk = kanji, 0xFF = space, 0xF6 Scroll, 0xF7-F9 = line 1/2/3,
#   0xFA Waitkey, 0xFB end, 0xFC pp = Speed, 0xFE ss[ pp] = extended command.
#
# Glyph index: 1-byte code c -> glyph c ; kanji kk -> glyph 0x100 + kk.

import os, struct, io
import _embedded

LOROM = lambda s: ((s >> 16) & 0x7F) * 0x8000 + (s & 0x7FFF)
DLG_BEG = LOROM(0x1C8000)
DLG_END = DLG_BEG + 0x7356

# Bytes emitted as "[art:HH]" tokens (icons/arrows with no plain-text meaning);
# the runtime resolves them through the atlas's 0xE000+index aliases.
ART_CODES = set(range(0xCA, 0xCD)) | {0xD2, 0xD3} | set(range(0xD9, 0xF6)) - {0xEC}

_EXTCMD = {
    0x68: "Choose", 0x6A: "Name", 0x71: "Choose3", 0x72: "Choose2",
    0x73: "Scroll", 0x74: "1", 0x75: "2", 0x76: "3", 0x7E: "Waitkey",
}
_EXTCMD_P = {
    0x6B: "Window", 0x6C: "Number", 0x6D: "Position", 0x6E: "ScrollSpd",
    0x77: "Color", 0x78: "Wait", 0x79: "Sound", 0x7A: "Speed",
}

# ---------------------------------------------------------------------------
def load_encoding():
    """glyph index (int) -> unicode code point."""
    cp = {}
    for raw in _embedded.JP_CHARACTER_ENCODE.splitlines():
        parts = raw.rstrip("\n").split(None, 2)
        if len(parts) < 2:
            continue
        if parts[0] == "FD":
            if len(parts) > 2 and parts[2][:1]:
                cp[0x100 + int(parts[1], 16)] = ord(parts[2][:1])
        else:
            try:
                c = int(parts[0], 16)
            except ValueError:
                continue
            if parts[1][:1]:
                cp[c] = ord(parts[1][:1])
    return cp

# ---------------------------------------------------------------------------
def decode_dialogue(rom):
    """Return the 395 JP messages in bracket-code text format."""
    idx2cp = load_encoding()
    def ch(code):
        c = idx2cp.get(code)
        if code in ART_CODES or c is None or c > 0xFFFF or code == 0xE4:
            return f"[art:{code:02X}]"
        return chr(c)

    p, msgs, cur = DLG_BEG, [], []
    while p < DLG_END:
        b = rom[p]; p += 1
        if b == 0xFB:
            msgs.append("".join(cur)); cur = []
        elif b == 0xFF:
            cur.append(" ")
        elif b == 0xFD:
            cur.append(ch(0x100 + rom[p])); p += 1
        elif b == 0xFC:
            cur.append(f"[Speed {rom[p]:02d}]"); p += 1
        elif b == 0xFE:
            s = rom[p]; p += 1
            if s in _EXTCMD_P:
                cur.append(f"[{_EXTCMD_P[s]} {rom[p]:02d}]"); p += 1
            else:
                cur.append(f"[{_EXTCMD.get(s, f'FE{s:02X}')}]")
        elif b == 0xF6:
            cur.append("[Scroll]")
        elif b in (0xF7, 0xF8, 0xF9):
            cur.append(f"[{b - 0xF6}]")
        elif b == 0xFA:
            cur.append("[Waitkey]")
        else:
            cur.append(ch(b))
    return msgs

# The JP raw message list (395) and the US-compiled array (397, the one the
# game's dialogue_message_index points at) line up 1:1 except:
#   US 1..11   == JP 1..11
#   US 12, 13  = two [Selchg] menu selectors JP does not have (only ">" cursors,
#               so the stock US render is fine there)
#   US 14..397 == JP 12..395
# Verified end to end (spot-checked at US 52/102/152/202/252/302/352/395/397).
def align_to_us(jp_msgs):
    """Return 397 messages indexed like the US dialogue array ('' = fall back)."""
    out = []
    for k in range(397):                 # 0-based
        if k <= 10:
            out.append(jp_msgs[k])
        elif k <= 12:
            out.append('')               # US 12, 13
        else:
            out.append(jp_msgs[k - 2])
    return out

# ---------------------------------------------------------------------------
# Font: sliced from the ripped decompressed sheet (jp_font_sheet.png). The JP
# ROM stores this font compressed with a bespoke bit-transpose scheme; the
# sheet is the same glyphs already unpacked, so we use it directly.
#
# Sheet layout: a 32-column grid of 11x16 cells.
#   rows 0..7   -> 1-byte codes 0x00..0xFF  (cell N -> glyph index N)
#   rows 8..15  -> kanji 0x00..0xFF         (cell 256+K -> glyph index 0x100+K)
# Colours: (0,0,112)=blue outline -> index 1, (248,248,248)=white fill ->
# index 2, (200,0,0) and (224,168,0) -> index 3. These map straight onto the
# game's message palette (HUD sub-palette 6: 1 blue, 2 white, 3 red).
CELL_W, CELL_H, SHEET_COLS = 11, 16, 32
_SHEET_COLOUR = {(0, 0, 112): 1, (248, 248, 248): 2, (200, 0, 0): 3, (224, 168, 0): 3}

def _sheet_glyphs():
    """glyph index -> (advance, 16 rows of 11 colour indices)."""
    from PIL import Image
    im = Image.open(io.BytesIO(_embedded.JP_FONT_SHEET_PNG)).convert("RGB")
    px = im.load()
    out = {}
    for row in range(16):
        for col in range(SHEET_COLS):
            rows, width = [], 0
            for y in range(row*CELL_H, row*CELL_H + CELL_H):
                r = [_SHEET_COLOUR.get(px[x, y], 0)
                     for x in range(col*CELL_W, col*CELL_W + CELL_W)]
                for x, v in enumerate(r):
                    if v:
                        width = max(width, x + 1)
                rows.append(r)
            if width == 0:
                continue
            cell = row * SHEET_COLS + col
            gi = cell if row < 8 else 0x100 + (cell - 256)
            out[gi] = (max(width + 1, 4), rows)
    return out

def extract_font():
    """CJKA v4 atlas: header + records sorted by code point.
       "CJKA" u16 ver=4 u16 cell_w=16 u16 cell_h=16 u16 count
       record: u32 codepoint  u32 advance  16 x (u16 bp0, u16 bp1)  (BE rows,
       MSB = leftmost pixel; colour index = bp0bit | bp1bit << 1)."""
    idx2cp = load_encoding()
    glyphs = _sheet_glyphs()
    recs = {}
    for gi, (adv, rows) in glyphs.items():
        packed = b""
        for r in rows:
            bp0 = bp1 = 0
            for x, ci in enumerate(r):
                if ci & 1: bp0 |= 1 << (15 - x)
                if ci & 2: bp1 |= 1 << (15 - x)
            packed += struct.pack(">HH", bp0, bp1)
        recs[0xE000 + gi] = (adv, packed)
        cp = idx2cp.get(gi)
        if cp is not None:
            recs.setdefault(cp, (adv, packed))
    ordered = sorted(recs.items())
    out = bytearray(b"CJKA")
    out += struct.pack("<HHHH", 4, 16, 16, len(ordered))
    for cp, (adv, packed) in ordered:
        out += struct.pack("<II", cp, adv) + packed
    return bytes(out)

def font_preview_png(path):
    from PIL import Image
    pal = [(15, 15, 22), (0, 0, 180), (245, 245, 245), (200, 0, 0)]
    glyphs = sorted(_sheet_glyphs().items())
    s, cols, pad = 5, 40, 2
    nrow = (len(glyphs) + cols - 1) // cols
    im = Image.new("RGB", (cols*(16*s+pad), nrow*(16*s+pad)), pal[0])
    px = im.load()
    for k, (gi, (adv, rows)) in enumerate(glyphs):
        ox, oy = (k % cols)*(16*s+pad), (k // cols)*(16*s+pad)
        for r, rr in enumerate(rows):
            for x, ci in enumerate(rr):
                if ci:
                    for dy in range(s):
                        for dx in range(s):
                            px[ox+x*s+dx, oy+r*s+dy] = pal[ci]
    im.save(path)
