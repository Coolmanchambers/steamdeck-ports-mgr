# Rebuilds ONLY save slot 3 (index 2) of ../saves/sram.dat.
# Built entirely from code - no embedded .sav. Slots 1 & 2 are kept as-is.
# Run from python\ , with the game CLOSED :  python.exe make_save.py
#
# Result: every item, gold sword, 20 hearts (full), full magic + 1/2 upgrade,
# 9999 rupees, 255 keys, all 3 pendants + 7 crystals, progress = end-game so the
# intro is skipped (spawns at the Sanctuary), Ganon NOT fought.
# The underworld/overworld "room" flags are left clear, so on the map the
# dungeons read as unvisited and their chests can be re-opened - cosmetic, it
# does not affect HUD testing.
import os, struct

SLOT = 2
DIST = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAVES = os.path.join(DIST, 'saves')
os.makedirs(SAVES, exist_ok=True)
PATH = os.path.join(SAVES, 'sram.dat')

# keep the player's existing slots 1 & 2 if a save file is already there
if os.path.isfile(PATH):
    cur = open(PATH, 'rb').read()
    sram = bytearray(cur) if len(cur) == 8192 else bytearray(8192)
else:
    sram = bytearray(8192)

slot = bytearray(0x500)
def b(o, v): slot[o] = v & 0xFF
def w(o, v): struct.pack_into('<H', slot, o, v & 0xFFFF)

# --- items ( $7EF340.. ) ----------------------------------------------------
b(0x340, 4)     # bow: silver + arrows
b(0x341, 2)     # boomerang: red
b(0x342, 1)     # hookshot
b(0x343, 50)    # bombs
b(0x344, 2)     # powder
b(0x345, 1); b(0x346, 1)                 # fire rod, ice rod
b(0x347, 1); b(0x348, 1); b(0x349, 1)    # bombos, ether, quake
b(0x34A, 1); b(0x34B, 1)                 # lamp, hammer
b(0x34C, 3)     # flute (bird)
b(0x34D, 1); b(0x34E, 1)                 # bug net, book
b(0x350, 1); b(0x351, 1)                 # somaria, byrna
b(0x352, 1); b(0x353, 2)                 # cape, mirror
b(0x354, 2)     # gloves: titan's mitt
b(0x355, 1); b(0x356, 1); b(0x357, 1)    # boots, flippers, moon pearl
b(0x359, 4)     # sword: gold
b(0x35A, 3)     # shield: mirror
b(0x35B, 2)     # armor: red mail
b(0x35C, 6); b(0x35D, 4); b(0x35E, 2); b(0x35F, 5)  # bottles: bee/blue/red/fairy
b(0x379, 0xFE)  # ability flags: dash(0x04)/lift(0x40)/read/swim - owning an item
                # isn't enough, this bitfield gates the A-button actions
                # (0xFE = every ability, matching a real end-game save)

# --- meters --------------------------------------------------------------
w(0x360, 9999); w(0x362, 9999)           # rupees goal / current
b(0x36C, 0xA0); b(0x36D, 0xA0)           # HP capacity / current : 20 hearts full
b(0x36E, 0x80)                           # magic : full
b(0x37B, 1)                              # magic usage : 1/2
b(0x36F, 0xFF)                           # keys
b(0x377, 70)                             # arrows
b(0x374, 0x07)                           # all 3 pendants
b(0x37A, 0x7F)                           # all 7 crystals

# --- progress / event bytes (from a genuine end-game state) ---------------
b(0x3C5, 0x03)          # progress indicator : end-game (skips intro, no bed)
b(0x3C6, 0x77); b(0x3C7, 0x08)
b(0x3C8, 0x01)          # start location : Sanctuary
b(0x3C9, 0x3B); b(0x3CA, 0x40)
b(0x3CD, 0xC8); b(0x3CE, 0x07); b(0x3CF, 0x7F); b(0x3D0, 0x07)
# per-dungeon map / compass / big-key + small-key counts
for a, v in ((0x3E7,1),(0x3EB,4),(0x3ED,5),(0x3EF,2),(0x3F1,0xB),(0x3F3,0xA),
             (0x3F5,8),(0x3F7,0xC),(0x3F9,0xA),(0x3FB,6),(0x3FD,2),(0x3FF,3),
             (0x401,3),(0x403,2)):
    b(a, v)
w(0x405, 0xFFFF)        # died counter

# --- name : "Paimon"  (values from the in-game name-entry grid:
#     P=0x0F  a=0x2A  i=0x42  m=0x46  o=0x48  n=0x47 ) --------------------
for k, ch in enumerate((0x0F, 0x2A, 0x42, 0x46, 0x48, 0x47)):
    w(0x3D9 + k * 2, ch)

w(0x3E5, 0x55AA)        # file-present marker

# --- checksum : the 0x280 slot words must sum to 0x5A5A ------------------
s = 0
for i in range(0x27F):
    s = (s + struct.unpack_from('<H', slot, i * 2)[0]) & 0xFFFF
struct.pack_into('<H', slot, 0x27F * 2, (0x5A5A - s) & 0xFFFF)

off = SLOT * 0x500
sram[off: off + 0x500] = slot
sram[off + 0xF00: off + 0xF00 + 0x500] = slot   # mirror

open(PATH, 'wb').write(sram)
print(f"wrote slot {SLOT + 1} of {PATH}")
print("  file 'Paimon' - every item, 20 hearts (full), full magic, 9999 rupees,")
print("  all pendants + crystals, progress = end-game.  slots 1 & 2 untouched.")
print("  (close the game before running this)")
