import array
import sys
import hashlib
import os
from functools import lru_cache

def cache(user_function):
  'Simple lightweight unbounded cache.  Sometimes called "memoize".'
  return lru_cache(maxsize=None)(user_function)

# one level up from python\  (= the launcher's folder); absolute so it survives
# restool.py chdir'ing into the assets\ scratch dir.
DEFAULT_ROM_DIRECTORY = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

# The US base ROM that every asset (graphics, rooms, music, the Latin VWF font)
# is extracted from.
ZELDA3_SHA1_US = '6D4F10A8B10E10DBE624CB23CF03B88BB8252973'

# Official Nintendo releases -> text format. Used by --extract-dialogue only as
# a fallback: it fills in the format when nothing was specified, and warns (does
# not block) when it disagrees with an explicit --as / folder name. Unknown
# ROMs (romhacks, fan translations) just aren't in here.
ZELDA3_SHA1 = {
  # Official Nintendo releases
  '6D4F10A8B10E10DBE624CB23CF03B88BB8252973': 'us',    # USA
  'CCE2817177FE8D0CA2409934B2777526FE7008BC': 'us',    # USA, Europe (Switch Online) -- NSO dump, NTSC data
  '7C073A222569B9B8E8CA5FCB5DFEC3B5E31DA895': 'en',    # Europe (PAL English)
  '2E62494967FB0AFDF5DA1635607F9641DF7C6559': 'de',    # Germany
  '229364A1B92A05167CD38609B1AA98F7041987CC': 'fr',    # France
  'C1C6C7F76FFF936C534FF11F87A54162FC0AA100': 'fr-c',  # Canada (Fr)
  'E7E852F0159CE612E3911164878A9B08B3CB9060': 'ja',    # Japan
  '52F470C80157F6843839C39E3BF52AFBB42FB957': 'ja',    # Japan (Rev 1)
  '6D9FA9006C160A0C81DB913BCD0EA3E7CC249BC9': 'ja',    # Japan (Rev 2)
  '169EC9CC3797ACA473371DF3F9BFBAB9E57FCDD5': 'ja',    # Japan (Rev 2) (Switch Online)

  # Fan translations (romhacking.net)
  '461FCBD700D1332009C0E85A7A136E2A8E4B111E': 'es',            # Spanish    - translations/2195
  '3C4D605EEFDA1D76F101965138F238476655B11D': 'pl',            # Polish     - translations/5760
  'D0D09ED41F9C373FE6AFDCCAFBF0DA8C88D3D90D': 'pt',            # Portuguese - translations/6530
  'FA8ADFDBA2697C9A54D583A1284A22AC764C7637': 'nl',            # Dutch      - translations/1124
  '43CD3438469B2C3FE879EA2F410B3EF3CB3F1CA4': 'sv',            # Swedish    - translations/982
  # US-format translations (reuse the US alphabet + dictionary, plain LangUS)
  'ADA2B22BBDFF14DC25B0A4B224656BFD043C083D': 'ga',            # Irish 1.00
  '92DB633BC1FAD0D865794EB437EBC81EC076FDC7': 'redux',         # English Redux 10.2.4
  'D2A38D30AD79B95DC5CC3B7EF0657ED1B966EC98': 'reduxretrans',  # English Redux Retranslation 10.2.4
  # not compatible without a dedicated Lang class (own alphabet / dictionary):
  #   Catalan  26E12E97634D0880E34CE58379762B4D385E306E  (uses bytes past the US alphabet)
  #   Galician 2C14618EDC9808C1BBF550CD15791912D668E0A7  (rebuilt compression dictionary)
}

# SHA-1 of the extracted Latin VWF font (languages/<code>/<code>.png) for each
# base whose alphabet differs from US. text_compression.resolve_base() uses this:
# a folder whose font matches one of these compiles against that base's
# alphabet/dictionary, wherever the folder lives and with no sibling folders
# required. Each hash was verified by re-extracting from the ROM in ZELDA3_SHA1
# (deterministic).
FONT_SHA1 = {
  # Official Nintendo releases
  'D765C8D5148D10E106F3E43038E66B793906E354': 'us',    # USA / base (also the fall-through default)
  '2686597EF363A7C74706BC9709BC5BD5292D3425': 'de',    # Germany
  '8A6CDCDA5D39A32011656A86E05A13BDD82F65F4': 'fr',    # France
  'E2F508F5940FF0F8C0F677971F15BDCD19D9F754': 'fr-c',  # Canada (Fr)
  'DCB8411D276516600AAF252AB9D59448600423B1': 'en',    # Europe (PAL English)
  # Fan translations (romhacking.net) -- each has its own alphabet tuned to
  # that specific ROM, so its font must map back to that base
  '816BBA0FE7D61C0EDB4AC99823E0F003274659C6': 'es',    # Spanish 1.11
  'C8E428053E738320CEAB2507668BE44FD3EFAF6D': 'pl',    # Polish 1.1
  'CC2F04FF4B26AB96FD85D7C5A7E4B453F5B78419': 'pt',    # Portuguese BETA
  # nl / sv: add once extracted from their fan-translation ROMs
}

def load_rom(filename, support_multilanguage = False, force_language = None):
  global ROM
  ROM = LoadedRom(filename, support_multilanguage, force_language)
  return ROM

def get_byte(addr):
  return ROM.get_byte(addr)

@cache
def get_bytes(addr, n):
  return ROM.get_bytes(addr, n)

@cache
def get_words(addr, n):
  return ROM.get_words(addr, n)

def get_int8(ea):
  b = get_byte(ea)
  if b & 0x80: b -= 256
  return b

def get_int16(ea):
  b = get_word(ea)
  if b & 0x8000: b -= 65536
  return b

def get_word(addr):
  return ROM.get_word(addr)


class LoadedRom:
  def __init__(self, path = None, support_multilanguage = False, force_language = None):
    rom_path = self.__get_rom_path(path)
    self.ROM = open(rom_path, 'rb').read()

    # Remove the SMC header?
    if (len(self.ROM) & 0xfffff) == 0x200:
      self.ROM = self.ROM[0x200:]

    hash = hashlib.sha1(self.ROM).hexdigest().upper()
    self.detected = ZELDA3_SHA1.get(hash)      # official/known ROM -> its format, else None

    # One distributed Swedish patch ships with a stray 0x200 header on top of an
    # already odd size; drop it so offsets line up.
    if self.detected == 'sv' and len(self.ROM) == 0x10083b:
      self.ROM = self.ROM[0x200:]

    self.language = 'us' if hash == ZELDA3_SHA1_US else None

    # --as <lang> / --name: caller states the text format. Otherwise the ROM
    # must be the US base.
    if force_language != None:
      self.language = force_language
      return

    if support_multilanguage:
      if self.language == None:
        raise Exception(f"\n\nUnrecognised ROM ({hash}). For a translation ROM, pass "
                        f"--as <us|de|fr|fr-c|en|es|pl|pt|nl|sv|ja>. Only the US base ROM "
                        f"({ZELDA3_SHA1_US}) is auto-detected.")
    else:
      if self.language != 'us':
        raise Exception(f"\n\nROM with hash {hash} not supported.\n\nExpected {ZELDA3_SHA1_US}.\nPlease verify your ROM is \"Legend of Zelda, The - A Link to the Past (USA)\"");

  def get_byte(self, ea):
    assert (ea & 0x8000)
    ea = ((ea >> 16) & 0x7f) * 0x8000 + (ea & 0x7fff)
    return self.ROM[ea]

  def get_word(self, ea):
    return self.get_byte(ea) + self.get_byte(ea + 1) * 256

  def get_24(self, ea):
    return self.get_byte(ea) + self.get_byte(ea + 1) * 256 + self.get_byte(ea + 2) * 65536

  def get_bytes(self, addr, n):
    r = bytearray()
    for i in range(n):
      r.append(self.get_byte(addr))
      addr += 1
      if (addr & 0x8000) == 0:
        addr += 0x8000
    return r

  def get_words(self, addr, n):
    r = []
    for i in range(n):
      r.append(self.get_word(addr))
      addr += 2
      if (addr & 0x8000) == 0:
        addr += 0x8000
    return r

  def __get_rom_path(self, path = None):
    if path is not None:
      rom_path = os.path.join(DEFAULT_ROM_DIRECTORY, path)
      if os.path.isfile(rom_path):
        return rom_path
      raise Exception(f"No ROM found at provided path {rom_path}.")

    # No -r: any roms/*.sfc|*.smc whose checksum is the US base ROM. ROMs live
    # only in the roms/ folder; the file keeps its original name.
    import glob
    roms_dir = os.path.join(DEFAULT_ROM_DIRECTORY, 'roms')
    for rom_path in sorted(glob.glob(os.path.join(roms_dir, '*.sfc')) +
                           glob.glob(os.path.join(roms_dir, '*.smc'))):
      b = open(rom_path, 'rb').read()
      if (len(b) & 0xfffff) == 0x200:
        b = b[0x200:]
      if hashlib.sha1(b).hexdigest().upper() == ZELDA3_SHA1_US:
        print(f'Using base ROM: {os.path.basename(rom_path)}')
        return rom_path
    raise Exception(f"No US base ROM ({ZELDA3_SHA1_US}) found in {roms_dir}.")



def split_list(l, n):
  return [l[i:i+n] for i in range(0, len(l), n)]

def to_hex(v):
  return '%#x' % v if v < -9 or v >9 else '%d'%v


def print_int_array(name, r, tname, decimal, split_length = 16, file = sys.stdout):
  rlen = len(r)
  rr = split_list(r, split_length )
  if decimal != None:
    if decimal:
      rr = [['%d' % s for s in t] for t in rr]
    else:
      rr = [[to_hex(s) for s in t] for t in rr]

  def pad_all_columns(rrs):
    colsiz = [max((0 if j >= len(r) else len(r[j])) for r in rrs) for j in range(len(rrs[0]))]
    def pad(c, i):
      return (' ' * (i - len(c))) + c
    return [[pad(c, colsiz[i]) for (i, c) in enumerate(r)] for r in rrs]

  if len(rr) == 1:
    print('static const %s %s[%d] = {%s};' % (tname, name, rlen, ", ".join(rr[0])), file = file)
  else:
    print('static const %s %s[%d] = {' % (tname, name, rlen), file = file)
    for t in pad_all_columns(rr):
      print("  " + "".join([(a + ', ') for a in t]), file = file)
    print('};', file = file)



class Reader:
  def __init__(self, ea, rb):
    self.ea, self.rb = ea, rb
  def next(self):
    r = self.rb(self.ea)
    self.ea += 1
    if (self.ea & 0xffff) == 0:
      self.ea += 0x8000
    return r

def decomp(ea, rb, offset_is_be = True, return_length = False):
  result = bytearray()
  reader = Reader(ea, rb)
  while True:
    b = reader.next()
    if b == 0xff:
      if return_length:
        return result, (reader.ea - ea) & 0x7fff
      else:
        return result
    if (b & 0xe0) != 0xe0:
      lx = b & 0x1f
      cmd = b & 0xe0
    else:
      cmd = (b << 3) & 0xe0
      lx = ((b & 3) << 8) | reader.next()
    lx += 1
    if cmd == 0x00: # 000 - literal
#      print('literal %d' % lx)
      while lx:
        result.append(reader.next())
        lx -= 1
    elif cmd & 0x80: # 1xx - copy
#      print('copy %d' % lx)
      offs = reader.next() << 8
      offs |= reader.next()
      if not offset_is_be: offs = ((offs >> 8) | (offs << 8)) & 0xffff
      while lx:
        result.append(result[offs])
        offs += 1
        lx -= 1
    elif (cmd & 0x40) == 0: # 00x - memset
#      print('memset %d' % lx)
      b = reader.next()
      while lx:
        result.append(b)
        lx -= 1
    elif (cmd & 0x20) == 0: # 010 - memset16
#      print('memsetw %d' % lx)
      b1, b2 = reader.next(), reader.next()
      while lx:
        result.append(b1)
        if lx==1: break
        result.append(b2)
        lx -= 2
    else: # 011 - incr
#      print('incr %d' % lx)
      b = reader.next()
      while lx:
        result.append(b)
        b = (b + 1) & 0xff
        lx -= 1


def decode_brr(get_byte, olds = (0, 0)):
  ea=0
  r = []
  old , older = olds
  while True:
    cmd = get_byte(ea)
    
    shift = cmd >> 4
    filter = (cmd >> 2) & 3
    #print("shift=%d, filter=%d" % (shift, filter))
    for i in range(16):
      t = (get_byte(ea+1+i//2) >> (0 if i & 1 else 4)) & 0xf
      s = (t & 7) - (t & 8)
      if shift <= 12:
        s = ((s << shift) >> 1)
      else:
        s = (s >> 3) << 12 # -2048 or 0

      if filter == 1:
        s += old*1+((-old*1) >> 4)
      elif filter == 2:
        s += old*2 + ((-old*3) >> 5)  - older + ((older*1) >> 4)
      elif filter == 3:
        s += old*2 + ((-old*13) >> 6) - older + ((older*3) >> 4)
      # saturate to 16 bits
      if s < -0x8000: s = -0x8000
      elif s >= 0x7fff: s = 0x7fff
      # wrap to 15 bits
      s = (s & 0x3fff) - (s & 0x4000)

      older, old = old, s
      #print('%d: 0x%x -> %d (shift %d, filter %d)' % (i, t, s*2, shift, filter))
      r.append(s*2)
    ea += 9
    if cmd & 1:
      break
  return array.array('h', r)

kBrrFilters = [
  lambda old, older: 0,
  lambda old, older: old*1+((-old*1) >> 4),
  lambda old, older: old*2 + ((-old*3) >> 5)  - older + ((older*1) >> 4),
  lambda old, older: old*2 + ((-old*13) >> 6) - older + ((older*3) >> 4)
]

def brr_get_one(old, rs, r):
  s = (rs << r) >> 1 if r <= 12 else (rs >> 3) << 12
  s += old
  s = -0x8000 if s < -0x8000 else 0x7fff if s > 0x7fff else s
  return (s & 0x3fff) - (s & 0x4000) # wrap to 15 bits

def encode_brr_generic(data, brr_repeat, olds = (0, 0), lossless=True):  
  assert len(data) % 16 == 0
  loop_enabled, loop_offset = 1 if brr_repeat != 0 else 0, 0
  result = []
  blk_data = [0] * 16
  best_data = [0] * 9
  p = 0
  best_old, best_older = olds
  while p < len(data):
#    print(p)
    best_err = 1 << 60
    startold, startolder = best_old, best_older

    if all(data[p + i] == 0 for i in range(16)):
      result.extend((loop_enabled * 2, 0, 0, 0, 0, 0, 0, 0, 0))
      p += 16
      continue
    for filter in range(4):
      if filter != 0 and (p == 0 or p == loop_offset):
        continue
      for r in range(12, 0, -1):
        blk_err = 0
        old, older = startold, startolder
        for i in range(16):
          s = kBrrFilters[filter](old, older)
          xs = data[p + i] >> 1 
          best_e = 1<<60
          for j in (0, 1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6, 7, -7, -8):
            s0 = brr_get_one(s, j, r)
            e = (xs - s0) * (xs - s0)
            if e < best_e:
              best_e, best_j, best_s0 = e, j, s0
              if e == 0:
                #print(j)
                break
          if best_e != 0 and lossless:
            break
          blk_err += best_e
          blk_data[i] = best_j & 0xf
          older, old = old, best_s0
        else:
          if blk_err < best_err:
            best_err = blk_err
            best_old, best_older = old, older
            best_data[0] = r << 4 | filter << 2 | loop_enabled << 1
            for i in range(8):
              best_data[i + 1] = blk_data[i * 2] << 4 | blk_data[i * 2 + 1]
    result.extend(best_data)
    if lossless: assert best_err==0
    p += 16
#  result[-9] |= 1
  return result

