#!/usr/bin/env python3
r"""
Link sprite converter for zelda3-PL  -  PNG <-> ZSPR, both directions.

No args (launcher option [7]):
    scan  ..\input\  and write results to  ..\output\
        input\foo.png   ->  output\foo.zspr
        input\bar.zspr  ->  output\bar.png
    (siblings of python\ , next to zelda3.exe / the launcher)

Manual:
    python link_sprite.py FILE [FILE ...] [-o OUTDIR] [--author NAME]

Sheet format (both ways): indexed 128 x 448 PNG, 16 colours, palette index 0 =
transparent - the standard ALttP "Link sheet", 16 x 56 tiles of 8x8, row-major.

ZSPR is ZSPR v1, sprite type 1, matching what main.c ParseLinkGraphics() reads:
    0x00 "ZSPR"  0x04 ver=1  0x05 checksum(4)
    0x09 pixOff(u32)  0x0D pixLen(u16)=0x7000
    0x0F palOff(u32)  0x13 palLen(u16)=0x78 (120)
    0x15 type(u16)=1  0x17 reserved(6)  then name/author strings, then data

Palette note: a PNG carries a single 16-colour palette, so PNG->ZSPR fills the
green/blue/red/bunny mail sub-palettes with a copy of it (armour upgrades won't
recolour Link). ZSPR->PNG shows the green-mail sub-palette. Pixels are exact
either way. For real per-mail palettes use SpriteSomething.
"""
import sys, os, glob, struct, argparse

try:
    from PIL import Image
except ImportError:
    sys.exit("Pillow required:  python.exe -m pip install pillow")

SHEET_W, SHEET_H = 128, 448
TILES_X, TILES_Y = SHEET_W // 8, SHEET_H // 8        # 16 x 56 = 896 tiles
PIXEL_LEN   = TILES_X * TILES_Y * 32                 # 0x7000
PALETTE_LEN = 15 * 2 * 4                             # 4 sub-palettes x 15 colours = 120


# ---------- colour helpers ----------

def rgb_to_snes(rgb):
    r, g, b = rgb[0] & 0xFF, rgb[1] & 0xFF, rgb[2] & 0xFF
    return ((b >> 3) << 10) | ((g >> 3) << 5) | (r >> 3)

def snes_to_rgb(c):
    r = (c & 0x1F) << 3
    g = ((c >> 5) & 0x1F) << 3
    b = ((c >> 10) & 0x1F) << 3
    return (r | r >> 5, g | g >> 5, b | b >> 5)      # replicate high bits -> full 0..255


# ---------- 8x8 tile <-> 32-byte SNES 4bpp planar ----------

def encode_tile(idx, ox, oy):
    out = bytearray(32)
    for row in range(8):
        b0 = b1 = b2 = b3 = 0
        base = (oy + row) * SHEET_W + ox
        for col in range(8):
            p = idx[base + col] & 0x0F
            bit = 0x80 >> col
            if p & 1: b0 |= bit
            if p & 2: b1 |= bit
            if p & 4: b2 |= bit
            if p & 8: b3 |= bit
        out[row * 2] = b0
        out[row * 2 + 1] = b1
        out[16 + row * 2] = b2
        out[16 + row * 2 + 1] = b3
    return out

def decode_tile(tile, idx, ox, oy):
    for row in range(8):
        b0 = tile[row * 2]
        b1 = tile[row * 2 + 1]
        b2 = tile[16 + row * 2]
        b3 = tile[16 + row * 2 + 1]
        base = (oy + row) * SHEET_W + ox
        for col in range(8):
            bit = 0x80 >> col
            p = ((b0 & bit) and 1) | ((b1 & bit) and 2) | ((b2 & bit) and 4) | ((b3 & bit) and 8)
            idx[base + col] = p & 0x0F


# ---------- PNG -> ZSPR ----------

def load_sheet(path):
    im = Image.open(path)
    if im.size != (SHEET_W, SHEET_H):
        raise ValueError(f"expected {SHEET_W}x{SHEET_H}, got {im.width}x{im.height}")
    if im.mode != "P":
        print(f"  note: {os.path.basename(path)} is {im.mode}; quantising to 16 colours")
        im = im.convert("RGB").quantize(colors=16, dither=0)

    idx = list(im.tobytes())
    if idx and max(idx) > 15:
        raise ValueError(f"uses palette index {max(idx)} (>15) - reduce to 16 colours")

    pal = list(im.getpalette() or [])
    pal += [0] * (48 - len(pal))
    trn = im.info.get("transparency")
    if isinstance(trn, int) and trn != 0:
        idx = [0 if p == trn else (trn if p == 0 else p) for p in idx]
        for k in range(3):
            pal[k], pal[trn * 3 + k] = pal[trn * 3 + k], pal[k]

    colors = [(pal[i * 3], pal[i * 3 + 1], pal[i * 3 + 2]) for i in range(16)]
    return idx, colors

def build_zspr(idx, colors, name, author):
    pixels = bytearray()
    for ty in range(TILES_Y):
        for tx in range(TILES_X):
            pixels += encode_tile(idx, tx * 8, ty * 8)
    assert len(pixels) == PIXEL_LEN

    sub = b"".join(struct.pack("<H", rgb_to_snes(colors[c])) for c in range(1, 16))
    palette = sub * 4
    assert len(palette) == PALETTE_LEN

    name_u16 = name.encode("utf-16-le") + b"\x00\x00"
    author_u16 = author.encode("utf-16-le") + b"\x00\x00"
    author_asc = author.encode("ascii", "replace") + b"\x00"

    header_len = 0x1D + len(name_u16) + len(author_u16) + len(author_asc)
    pix_off = header_len
    pal_off = pix_off + PIXEL_LEN

    h = bytearray()
    h += b"ZSPR"
    h += bytes([1])
    h += b"\x00\x00\x00\x00"
    h += struct.pack("<I", pix_off)
    h += struct.pack("<H", PIXEL_LEN)
    h += struct.pack("<I", pal_off)
    h += struct.pack("<H", PALETTE_LEN)
    h += struct.pack("<H", 1)
    h += b"\x00" * 6
    h += name_u16 + author_u16 + author_asc
    assert len(h) == header_len

    blob = bytes(h) + bytes(pixels) + bytes(palette)
    s = sum(blob) & 0xFFFF
    return blob[:5] + struct.pack("<HH", s, (0xFFFF - s) & 0xFFFF) + blob[9:]


# ---------- ZSPR -> PNG ----------

def zspr_to_png(data, out_path):
    if len(data) < 0x1D or data[:4] != b"ZSPR":
        raise ValueError("not a ZSPR file")
    pix_off = struct.unpack_from("<I", data, 9)[0]
    pix_len = struct.unpack_from("<H", data, 13)[0]
    pal_off = struct.unpack_from("<I", data, 15)[0]
    pal_len = struct.unpack_from("<H", data, 19)[0]
    if pix_len != PIXEL_LEN or pix_off + pix_len > len(data):
        raise ValueError(f"bad pixel block (off={pix_off} len={pix_len})")

    idx = bytearray(SHEET_W * SHEET_H)
    p = pix_off
    for ty in range(TILES_Y):
        for tx in range(TILES_X):
            decode_tile(data[p:p + 32], idx, tx * 8, ty * 8)
            p += 32

    # palette: green-mail sub-palette (15 colours) -> PNG indices 1..15, 0 = transparent
    palette = [255, 0, 255]                      # index 0 marker colour
    if pal_off + 30 <= len(data) and pal_len >= 30:
        for c in range(15):
            col = struct.unpack_from("<H", data, pal_off + c * 2)[0]
            palette += list(snes_to_rgb(col))
    else:
        palette += [0, 0, 0] * 15
    palette += [0, 0, 0] * (256 - 16)

    im = Image.new("P", (SHEET_W, SHEET_H))
    im.putpalette(palette)
    im.frombytes(bytes(idx))
    im.info["transparency"] = 0
    im.save(out_path, transparency=0)


# ---------- driver ----------

def convert_one(src, outdir, author):
    ext = os.path.splitext(src)[1].lower()
    base = os.path.splitext(os.path.basename(src))[0]
    if ext == ".png":
        idx, colors = load_sheet(src)
        blob = build_zspr(idx, colors, base, author)
        dst = os.path.join(outdir, base + ".zspr")
        with open(dst, "wb") as f:
            f.write(blob)
        return dst, len(blob)
    if ext == ".zspr":
        dst = os.path.join(outdir, base + ".png")
        zspr_to_png(open(src, "rb").read(), dst)
        return dst, os.path.getsize(dst)
    raise ValueError("not a .png or .zspr")

def main():
    ap = argparse.ArgumentParser(description="Link sprite PNG <-> ZSPR converter")
    ap.add_argument("files", nargs="*", help="files/globs; default: scan ..\\input\\")
    ap.add_argument("-o", "--outdir", help="output dir (default: ..\\output\\)")
    ap.add_argument("--author", default="zelda3-PL")
    a = ap.parse_args()

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if a.files:
        items = []
        for pat in a.files:
            hits = sorted(glob.glob(pat))
            items.extend(hits if hits else [pat])
        outdir = a.outdir or "."
    else:
        indir = os.path.join(root, "input")
        outdir = a.outdir or os.path.join(root, "output")
        os.makedirs(indir, exist_ok=True)
        items = sorted(glob.glob(os.path.join(indir, "*.png")) +
                       glob.glob(os.path.join(indir, "*.zspr")))
        if not items:
            print(f"input\\ is empty - drop .png and/or .zspr files in:\n  {indir}")
            return
    os.makedirs(outdir, exist_ok=True)

    ok = 0
    for src in items:
        try:
            dst, n = convert_one(src, outdir, a.author)
        except (OSError, ValueError, AssertionError) as e:
            print(f"  SKIP  {os.path.basename(src)} : {e}")
            continue
        arrow = "PNG ->ZSPR" if src.lower().endswith(".png") else "ZSPR->PNG "
        print(f"  {arrow}  {os.path.basename(src)}  ->  {os.path.basename(dst)}  ({n} bytes)")
        ok += 1
    print(f"done - {ok}/{len(items)} converted -> {outdir}")


if __name__ == "__main__":
    main()
