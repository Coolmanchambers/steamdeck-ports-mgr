import argparse
import util
import sys
import os

# scripts live in python\ ; they work in a sibling assets\ scratch dir that is
# created on first run (NOT shipped). roms\ , languages\ and zelda3_assets.dat
# sit one level up from there, next to the launcher.
_ASSETS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'assets')
for _d in ('', 'dungeon', 'overworld', 'sound', 'sprites', 'img', 'tables'):
  os.makedirs(os.path.join(_ASSETS, _d), exist_ok=True)
os.chdir(_ASSETS)


parser = argparse.ArgumentParser(description='Resource tool used to build zelda3_assets.dat', allow_abbrev=False)
parser.add_argument('-r', '--rom', nargs='?', metavar='ROM')
parser.add_argument('--extract-from-rom', '-e', action='store_true', help='Extract/overwrite things from the ROM')

optional = parser.add_argument_group('Language settings')
optional.add_argument('--extract-dialogue', action='store_true', help = 'Extract dialogue from a translated ROM')
optional.add_argument('--auto', action='store_true', help = 'Scan for ROMs, identify each by SHA-1 and extract every known one into its canonical languages/<code>/ folder.')
optional.add_argument('--languages', action='store', metavar='L1,L2', help = 'Comma separated list of languages to build; each must be a folder in languages/ (de,fr,fr-c,en,es,pl,pt,nl,sv,ja, or anything extracted with --extract-dialogue).')
optional.add_argument('--as', dest='as_lang', metavar='BASE', help = "With --extract-dialogue: force the ROM's text format (us/de/fr/fr-c/en/es/pl/pt/nl/sv/ja) instead of inferring it from --name.")
optional.add_argument('--name', metavar='CODE', help = "With --extract-dialogue: folder name under languages/ and the value to put in zelda3.ini (lets several ROMs of the same base coexist).")

optional = parser.add_argument_group('Debug things')
optional.add_argument('--no-build', action='store_true', help="Don't actually build zelda3_assets.dat")
optional.add_argument('--print-strings', action='store_true', help="Print all dialogue strings")
optional.add_argument('--print-assets-header', action='store_true')

optional = parser.add_argument_group('Image handling')
optional.add_argument('--sprites-from-png', action='store_true', help="When compiling, load sprites from png instead of from ROM")

args = parser.parse_args()

if args.auto:
  import glob, hashlib, subprocess
  taken, done, skipped = set(), 0, 0
  romsdir = os.path.join(util.DEFAULT_ROM_DIRECTORY, 'roms')
  for p in sorted(glob.glob(os.path.join(romsdir, '*.sfc')) + glob.glob(os.path.join(romsdir, '*.smc'))):
    ap = os.path.abspath(p)
    b = open(ap, 'rb').read()
    if (len(b) & 0xfffff) == 0x200:
      b = b[0x200:]
    code = util.ZELDA3_SHA1.get(hashlib.sha1(b).hexdigest().upper())
    label = os.path.basename(ap)
    if code is None:
      print(f"  skip (unknown)  {label}", flush=True); skipped += 1; continue
    if code == 'us':
      print(f"  skip (US base)  {label}", flush=True); skipped += 1; continue
    if code in taken:
      print(f"  skip ('{code}' already done)  {label}", flush=True); skipped += 1; continue
    taken.add(code)
    print(f"  extract [{code}]  {label}", flush=True)
    subprocess.run([sys.executable, os.path.abspath(__file__),
                    '--extract-dialogue', '-r', ap, '--name', code], check=False)
    done += 1
  print(f"\n{done} language(s) extracted, {skipped} ROM(s) skipped.")
  sys.exit(0)

if args.extract_dialogue:
  import text_compression, sprite_sheets as _ss, glob
  # what the caller asked for
  req_name = args.name or (args.as_lang or 'us')
  req_base = args.as_lang or text_compression.resolve_base(req_name)
  if req_base not in text_compression.kLanguages:
    sys.exit(f"unknown base language '{req_base}' -- use --as us/de/fr/fr-c/en/es/pl/pt/nl/sv/ja")
  ROM = util.load_rom(args.rom, True, force_language=req_base)

  if ROM.detected:
    # known ROM: the predefined code wins for BOTH folder and format,
    # whatever --name / --as said.
    name = base = ROM.detected
    if req_name != name or (args.as_lang and args.as_lang != base):
      print(f"checksum: known ROM -> '{name}' (ignoring the name/format given)")
  else:
    name, base = req_name, req_base

  # fresh extraction: wipe any previous artefacts for this language
  _dir = os.path.join(text_compression._LANGDIR, name)
  os.makedirs(_dir, exist_ok=True)
  for _f in glob.glob(os.path.join(_dir, name + '.*')):
    os.remove(_f)
  text_compression._resolve_cache.pop(name, None)

  if name != base:
    text_compression.kLanguages[name] = text_compression.kLanguages[base]
    if base in _ss.kFontTypes:          # ja has no Latin VWF entry
      b = _ss.kFontTypes[base]
      _ss.kFontTypes[name] = (b[0], b[1], _ss._fontpng(name), b[3])

  ROM.language = name
  ROM.base = base
  import extract_resources, sprite_sheets
  sprite_sheets.decode_font()
  extract_resources.print_dialogue()
  print(f"extracted '{name}' (format {base}) -> languages/{name}/")
  sys.exit(0)

ROM = util.load_rom(args.rom)

want_compile = True

if args.extract_from_rom:
  import extract_resources
  extract_resources.main()

if args.print_strings:
  import text_compression
  text_compression.print_strings(ROM)
  want_compile = False

if want_compile and not args.no_build:
  import compile_resources
  compile_resources.main(args)



